public static class StaticValues
{
    public static int winner = -1;
}