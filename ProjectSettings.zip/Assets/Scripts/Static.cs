public static class staticValues
{
    public static int winner = -1;
}